package com.fatimabisesheva.divconq.sort;

import com.fatimabisesheva.divconq.metrics.Metrics;

public class MergeSort {
    private static final int CUTOFF = 32;

    public static void sort(int[] a, Metrics m) {
        if (a == null || a.length <= 1) return;
        int[] buf = new int[a.length];
        System.arraycopy(a, 0, buf, 0, a.length);
        mergesort(buf, 0, a.length - 1, a, m);
    }

    private static void mergesort(int[] src, int lo, int hi, int[] dest, Metrics m) {
        m.enter();
        try {
            if (hi - lo + 1 <= CUTOFF) {
                for (int i = lo; i <= hi; i++) dest[i] = src[i];
                for (int i = lo + 1; i <= hi; i++) {
                    int key = dest[i];
                    int j = i - 1;
                    while (j >= lo && dest[j] > key) {
                        dest[j + 1] = dest[j]; m.incComparisons(1); j--;
                    }
                    dest[j + 1] = key;
                }
                return;
            }
            int mid = (lo + hi) >>> 1;
            mergesort(dest, lo, mid, src, m);
            mergesort(dest, mid + 1, hi, src, m);

            int i = lo, j = mid + 1, k = lo;
            while (i <= mid && j <= hi) {
                m.incComparisons(1);
                if (src[i] <= src[j]) dest[k++] = src[i++];
                else dest[k++] = src[j++];
            }
            while (i <= mid) dest[k++] = src[i++];
            while (j <= hi) dest[k++] = src[j++];
        } finally {
            m.exit();
        }
    }
}
