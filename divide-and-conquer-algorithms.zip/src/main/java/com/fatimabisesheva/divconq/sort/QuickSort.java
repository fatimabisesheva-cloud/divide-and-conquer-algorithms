package com.fatimabisesheva.divconq.sort;

import com.fatimabisesheva.divconq.metrics.Metrics;
import com.fatimabisesheva.divconq.util.Utils;

import java.util.Random;

public class QuickSort {
    private static final int CUTOFF = 16;
    private static final Random RNG = new Random(12345);

    public static void sort(int[] a, Metrics m) {
        if (a == null || a.length <= 1) return;
        Utils.shuffle(a);
        quicksort(a, 0, a.length - 1, m);
    }

    private static void quicksort(int[] a, int lo, int hi, Metrics m) {
        while (lo < hi) {
            if (hi - lo + 1 <= CUTOFF) {
                Utils.insertionSort(a, lo, hi);
                return;
            }
            m.enter();
            int pivotIndex = lo + RNG.nextInt(hi - lo + 1);
            int pivot = a[pivotIndex];
            int t = a[pivotIndex]; a[pivotIndex] = a[hi]; a[hi] = t;

            int i = lo;
            for (int j = lo; j < hi; j++) {
                m.incComparisons(1);
                if (a[j] < pivot) {
                    int tmp = a[i]; a[i] = a[j]; a[j] = tmp; i++;
                }
            }
            int tmp = a[i]; a[i] = a[hi]; a[hi] = tmp;
            int leftSize = i - lo;
            int rightSize = hi - i;
            if (leftSize < rightSize) {
                quicksort(a, lo, i - 1, m);
                lo = i + 1;
            } else {
                quicksort(a, i + 1, hi, m);
                hi = i - 1;
            }
            m.exit();
        }
    }
}
