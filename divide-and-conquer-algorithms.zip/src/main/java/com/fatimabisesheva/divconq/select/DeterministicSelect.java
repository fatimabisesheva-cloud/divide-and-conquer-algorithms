package com.fatimabisesheva.divconq.select;

import com.fatimabisesheva.divconq.metrics.Metrics;
import java.util.Arrays;

public class DeterministicSelect {
    public static int select(int[] a, int k, Metrics m) {
        if (a == null || k < 0 || k >= a.length) throw new IllegalArgumentException();
        return select(a, 0, a.length - 1, k, m);
    }

    private static int select(int[] a, int lo, int hi, int k, Metrics m) {
        m.enter();
        try {
            while (true) {
                if (lo == hi) return a[lo];
                int pivot = pivotMedianOfMedians(a, lo, hi, m);
                int pivotIndex = partition(a, lo, hi, pivot, m);
                if (k == pivotIndex) return a[k];
                else if (k < pivotIndex) hi = pivotIndex - 1;
                else lo = pivotIndex + 1;
            }
        } finally {
            m.exit();
        }
    }

    private static int partition(int[] a, int lo, int hi, int pivotValue, Metrics m) {
        int i = lo;
        for (int j = lo; j <= hi; j++) {
            m.incComparisons(1);
            if (a[j] < pivotValue) { int tmp = a[i]; a[i++] = a[j]; a[j] = tmp; }
        }
        int pivotIndex = i;
        for (int j = i; j <= hi; j++) if (a[j] == pivotValue) { int tmp = a[pivotIndex]; a[pivotIndex] = a[j]; a[j] = tmp; break; }
        return pivotIndex;
    }

    private static int pivotMedianOfMedians(int[] a, int lo, int hi, Metrics m) {
        int n = hi - lo + 1;
        if (n <= 5) {
            Arrays.sort(a, lo, hi + 1);
            return a[lo + n/2];
        }
        int numMedians = 0;
        for (int i = lo; i <= hi; i += 5) {
            int subHi = Math.min(i + 4, hi);
            Arrays.sort(a, i, subHi + 1);
            int median = a[i + (subHi - i)/2];
            a[lo + numMedians] = median;
            numMedians++;
        }
        return select(a, lo, lo + numMedians - 1, lo + numMedians/2, m);
    }
}
