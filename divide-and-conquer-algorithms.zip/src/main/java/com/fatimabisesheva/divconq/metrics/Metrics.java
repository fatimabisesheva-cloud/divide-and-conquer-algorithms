package com.fatimabisesheva.divconq.metrics;

import java.util.concurrent.atomic.AtomicLong;

public class Metrics {
    private final AtomicLong comparisons = new AtomicLong();
    private final AtomicLong allocations = new AtomicLong();

    private final ThreadLocal<Integer> depth = ThreadLocal.withInitial(() -> 0);
    private final AtomicLong maxDepth = new AtomicLong();

    public void incComparisons(long delta) { comparisons.addAndGet(delta); }
    public void incAllocations(long delta) { allocations.addAndGet(delta); }

    public void enter() {
        int d = depth.get() + 1;
        depth.set(d);
        maxDepth.updateAndGet(prev -> Math.max(prev, d));
    }

    public void exit() {
        depth.set(depth.get() - 1);
    }

    public long getComparisons() { return comparisons.get(); }
    public long getAllocations() { return allocations.get(); }
    public long getMaxDepth() { return maxDepth.get(); }

    public void reset() {
        comparisons.set(0);
        allocations.set(0);
        maxDepth.set(0);
        depth.set(0);
    }
}
