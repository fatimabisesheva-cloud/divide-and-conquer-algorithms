package com.fatimabisesheva.divconq;

import com.fatimabisesheva.divconq.metrics.Metrics;
import com.fatimabisesheva.divconq.sort.MergeSort;
import com.fatimabisesheva.divconq.sort.QuickSort;
import com.fatimabisesheva.divconq.select.DeterministicSelect;
import com.fatimabisesheva.divconq.closest.ClosestPair;

import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.Random;

public class Main {
    public static void main(String[] args) throws Exception {
        if (args.length < 4) {
            System.out.println("Usage: <algo> <n> <repeats> <out.csv>");
            System.out.println("algo: mergesort | quicksort | select | closest");
            return;
        }
        String algo = args[0];
        int n = Integer.parseInt(args[1]);
        int repeats = Integer.parseInt(args[2]);
        String out = args[3];

        try (PrintWriter pw = new PrintWriter(new FileWriter(out, true))) {
            for (int r = 0; r < repeats; r++) {
                Metrics m = new Metrics();
                long t0 = System.nanoTime();
                if ("mergesort".equalsIgnoreCase(algo)) {
                    int[] a = randIntArray(n);
                    MergeSort.sort(a, m);
                } else if ("quicksort".equalsIgnoreCase(algo)) {
                    int[] a = randIntArray(n);
                    QuickSort.sort(a, m);
                } else if ("select".equalsIgnoreCase(algo)) {
                    int[] a = randIntArray(n);
                    int k = n/2;
                    DeterministicSelect.select(a, k, m);
                } else if ("closest".equalsIgnoreCase(algo)) {
                    ClosestPair.Point[] pts = randPoints(n);
                    ClosestPair.closest(pts, m);
                } else {
                    System.err.println("Unknown algo: " + algo);
                    return;
                }
                long t1 = System.nanoTime();
                double ms = (t1 - t0) / 1e6;
                pw.printf("%s,%d,%.3f,%d,%d,%d\n", algo, n, ms, m.getMaxDepth(), m.getComparisons(), m.getAllocations());
                pw.flush();
            }
        }
    }

    private static int[] randIntArray(int n) {
        Random rnd = new Random();
        int[] a = new int[n];
        for (int i = 0; i < n; i++) a[i] = rnd.nextInt();
        return a;
    }

    private static ClosestPair.Point[] randPoints(int n) {
        Random rnd = new Random();
        ClosestPair.Point[] pts = new ClosestPair.Point[n];
        for (int i = 0; i < n; i++) pts[i] = new ClosestPair.Point(rnd.nextDouble(), rnd.nextDouble());
        return pts;
    }
}
