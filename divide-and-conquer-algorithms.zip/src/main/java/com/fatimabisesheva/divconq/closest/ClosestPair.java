package com.fatimabisesheva.divconq.closest;

import com.fatimabisesheva.divconq.metrics.Metrics;

import java.util.Arrays;
import java.util.Comparator;

public class ClosestPair {
    public static class Point { public final double x, y; public Point(double x, double y) { this.x = x; this.y = y; } }

    public static double closest(Point[] pts, Metrics m) {
        if (pts.length < 2) return Double.POSITIVE_INFINITY;
        Point[] byX = pts.clone();
        Arrays.sort(byX, Comparator.comparingDouble(p -> p.x));
        Point[] byY = pts.clone();
        Arrays.sort(byY, Comparator.comparingDouble(p -> p.y));
        return rec(byX, 0, pts.length - 1, m);
    }

    private static double rec(Point[] byX, int lo, int hi, Metrics m) {
        m.enter();
        try {
            int n = hi - lo + 1;
            if (n <= 3) {
                double best = Double.POSITIVE_INFINITY;
                for (int i = lo; i <= hi; i++) for (int j = i+1; j <= hi; j++) {
                    best = Math.min(best, dist(byX[i], byX[j]));
                }
                return best;
            }
            int mid = (lo + hi) >>> 1;
            double midx = byX[mid].x;

            double dl = rec(byX, lo, mid, m);
            double dr = rec(byX, mid+1, hi, m);
            double d = Math.min(dl, dr);

            Point[] strip = new Point[n];
            int stripCnt = 0;
            for (int i = lo; i <= hi; i++) if (Math.abs(byX[i].x - midx) < d) strip[stripCnt++] = byX[i];
            Arrays.sort(strip, 0, stripCnt, Comparator.comparingDouble(p -> p.y));
            for (int i = 0; i < stripCnt; i++) {
                for (int j = i+1; j < stripCnt && (strip[j].y - strip[i].y) < d; j++) {
                    d = Math.min(d, dist(strip[i], strip[j]));
                }
            }
            return d;
        } finally {
            m.exit();
        }
    }

    private static double dist(Point a, Point b) {
        double dx = a.x - b.x; double dy = a.y - b.y; return Math.hypot(dx, dy);
    }
}
