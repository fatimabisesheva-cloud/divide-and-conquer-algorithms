package com.fatimabisesheva.divconq;

import com.fatimabisesheva.divconq.metrics.Metrics;
import com.fatimabisesheva.divconq.closest.ClosestPair;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertTrue;

public class ClosestPairTest {
    @Test
    public void testSmall() {
        ClosestPair.Point[] pts = new ClosestPair.Point[]{
            new ClosestPair.Point(0,0),
            new ClosestPair.Point(1,1),
            new ClosestPair.Point(0.1,0.1)
        };
        Metrics m = new Metrics();
        double d = ClosestPair.closest(pts, m);
        assertTrue(d > 0);
    }
}
