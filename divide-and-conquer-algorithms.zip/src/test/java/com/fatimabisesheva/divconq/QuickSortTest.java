package com.fatimabisesheva.divconq;

import com.fatimabisesheva.divconq.metrics.Metrics;
import com.fatimabisesheva.divconq.sort.QuickSort;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class QuickSortTest {
    @Test
    public void testRandom() {
        int[] a = {5,3,2,8,1,4};
        Metrics m = new Metrics();
        QuickSort.sort(a, m);
        int[] expected = {1,2,3,4,5,8};
        Arrays.sort(expected);
        assertArrayEquals(expected, a);
    }
}
