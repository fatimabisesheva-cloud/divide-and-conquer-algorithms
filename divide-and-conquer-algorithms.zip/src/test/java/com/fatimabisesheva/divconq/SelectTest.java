package com.fatimabisesheva.divconq;

import com.fatimabisesheva.divconq.metrics.Metrics;
import com.fatimabisesheva.divconq.select.DeterministicSelect;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class SelectTest {
    @Test
    public void testSelectRandom() {
        int[] a = {4,1,3,2,5};
        Metrics m = new Metrics();
        int kth = DeterministicSelect.select(a.clone(), 2, m);
        Arrays.sort(a);
        assertEquals(a[2], kth);
    }
}
