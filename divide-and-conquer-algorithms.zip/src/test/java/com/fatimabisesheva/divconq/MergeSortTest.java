package com.fatimabisesheva.divconq;

import com.fatimabisesheva.divconq.metrics.Metrics;
import com.fatimabisesheva.divconq.sort.MergeSort;
import org.junit.jupiter.api.Test;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertArrayEquals;

public class MergeSortTest {
    @Test
    public void testRandom() {
        int[] a = {5,3,2,8,1,4};
        Metrics m = new Metrics();
        MergeSort.sort(a, m);
        int[] expected = {1,2,3,4,5,8};
        assertArrayEquals(expected, a);
    }

    @Test
    public void testAdversarial() {
        int n = 1000;
        int[] a = new int[n];
        for (int i = 0; i < n; i++) a[i] = n - i;
        Metrics m = new Metrics();
        MergeSort.sort(a, m);
        Arrays.sort(a);
    }
}
